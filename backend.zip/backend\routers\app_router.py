"""
routers/app_router.py — FastAPI endpoints for GitHub App management.

Routes:
- GET  /api/app/installations -> List all installations accessible to user/orgs
- GET  /api/app/installations/{installation_id}/repos -> List repos for installation
- POST /api/app/installations/{installation_id}/repos/select -> Save repository selections
- POST /api/app/webhook -> Webhook receiver for GitHub App installation events
"""

import hashlib
import hmac
import logging
import os
from typing import Any, Dict, List

from auth.app_service import GitHubAppService, get_app_service
from auth.dependencies import get_current_user_optional, require_auth
from auth.models import (
    AccountType,
    InstallationResponse,
    InstallationStatus,
    RepoResponse,
    SelectReposRequest,
    SelectReposResponse,
    User,
)
from auth.store import (
    get_installation_by_id,
    get_installations_for_user,
    get_oauth_token,
    get_selected_repos_for_installation,
    upsert_installation,
)
from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.responses import RedirectResponse

logger = logging.getLogger("backend")

router = APIRouter(prefix="/api/app", tags=["GitHub App"])


@router.get("/installations", response_model=List[InstallationResponse])
async def list_user_installations(
    user: User = Depends(require_auth),
    app_service: GitHubAppService = Depends(get_app_service),
):
    """
    Lists all GitHub App installations associated with the authenticated user across personal & org accounts.
    """
    oauth_token = await get_oauth_token(user.id)
    user_access_token = oauth_token.access_token if oauth_token else ""
    await app_service.sync_user_installations(user.id, user_access_token)
    db_installations = await get_installations_for_user(user.id)
    results: List[InstallationResponse] = []

    for inst in db_installations:
        # Fetch repos for this installation

        repos_raw = await app_service.list_installation_repos(
            installation_id=inst.installation_id, user_access_token=user_access_token
        )

        selected_repos = await get_selected_repos_for_installation(inst.id)
        enabled_set = {r.repo_full_name.lower() for r in selected_repos}

        repo_models = [
            RepoResponse(
                repo_id=r.get("id", 0),
                full_name=r.get("full_name", ""),
                private=r.get("private", False),
                enabled=(r.get("full_name", "").lower() in enabled_set),
            )
            for r in repos_raw
        ]

        results.append(
            InstallationResponse(
                installation_id=inst.installation_id,
                account_login=inst.account_login,
                account_type=inst.account_type,
                status=inst.status,
                repositories=repo_models,
            )
        )

    return results


@router.get("/installations/{installation_id}/repos", response_model=List[RepoResponse])
async def list_installation_repos_endpoint(
    installation_id: int,
    user: User = Depends(require_auth),
    app_service: GitHubAppService = Depends(get_app_service),
):
    """Lists all repositories available for a specific installation."""
    inst = await get_installation_by_id(installation_id)
    if not inst:
        # Try syncing directly from GitHub App API if not in local DB yet
        inst = await app_service.sync_installation_from_github(
            installation_id, user_id=user.id
        )
        if not inst:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Installation {installation_id} not found.",
            )

    oauth_token = await get_oauth_token(user.id)
    user_access_token = oauth_token.access_token if oauth_token else None

    repos_raw = await app_service.list_installation_repos(
        installation_id=installation_id, user_access_token=user_access_token
    )

    selected = await get_selected_repos_for_installation(inst.id)
    enabled_set = {r.repo_full_name.lower() for r in selected}

    return [
        RepoResponse(
            repo_id=r.get("id", 0),
            full_name=r.get("full_name", ""),
            private=r.get("private", False),
            enabled=(r.get("full_name", "").lower() in enabled_set),
        )
        for r in repos_raw
    ]


@router.post(
    "/installations/{installation_id}/sync", response_model=InstallationResponse
)
async def sync_installation_endpoint(
    installation_id: int,
    user: User = Depends(require_auth),
    app_service: GitHubAppService = Depends(get_app_service),
):
    """
    Performs an explicit synchronization of GitHub App installation metadata & repositories from GitHub API.
    """
    inst = await app_service.sync_installation_from_github(
        installation_id, user_id=user.id
    )
    if not inst:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Unable to sync installation {installation_id} from GitHub API.",
        )

    oauth_token = await get_oauth_token(user.id)
    user_access_token = oauth_token.access_token if oauth_token else None

    repos_raw = await app_service.list_installation_repos(
        installation_id=installation_id, user_access_token=user_access_token
    )

    selected = await get_selected_repos_for_installation(inst.id)
    enabled_set = {r.repo_full_name.lower() for r in selected}

    repo_models = [
        RepoResponse(
            repo_id=r.get("id", 0),
            full_name=r.get("full_name", ""),
            private=r.get("private", False),
            enabled=(r.get("full_name", "").lower() in enabled_set),
        )
        for r in repos_raw
    ]

    return InstallationResponse(
        installation_id=inst.installation_id,
        account_login=inst.account_login,
        account_type=inst.account_type,
        status=inst.status,
        repositories=repo_models,
    )


@router.post(
    "/installations/{installation_id}/repos/select", response_model=SelectReposResponse
)
async def select_repositories_endpoint(
    installation_id: int,
    body: SelectReposRequest,
    user: User = Depends(require_auth),
    app_service: GitHubAppService = Depends(get_app_service),
):
    """Saves selected repositories for an installation to enable AI code review coverage."""
    try:
        enabled, disabled = await app_service.update_selected_repositories(
            installation_id=installation_id, repo_full_names=body.repo_full_names
        )
        return SelectReposResponse(
            installation_id=installation_id,
            enabled_repos=enabled,
            disabled_repos=disabled,
        )
    except ValueError as e:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    except Exception as e:
        logger.error(f"Error saving repository selections: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update repository selections.",
        )


@router.post("/webhook")
async def app_lifecycle_webhook(request: Request):
    """
    Handles GitHub App installation lifecycle webhook events (created, deleted, suspend, unsuspend).
    Updates local installation state in SQLite automatically.
    """
    await _verify_webhook_signature(request)
    payload = await request.json()
    action = payload.get("action")
    installation = payload.get("installation", {})
    inst_id = installation.get("id")

    if not inst_id:
        return {"status": "ignored", "reason": "NO_INSTALLATION_ID"}

    account = installation.get("account", {})

    if action in ("created", "unsuspend"):
        await upsert_installation(
            installation_id=inst_id,
            account_login=account.get("login", "unknown"),
            account_type=account.get("type", "User"),
            target_id=installation.get("target_id", account.get("id", 0)),
            target_type=installation.get("target_type", account.get("type", "User")),
            status="active",
        )
        logger.info(
            f"GitHub App installation {inst_id} ({account.get('login')}) registered/activated."
        )
    elif action in ("deleted", "suspend"):
        await upsert_installation(
            installation_id=inst_id,
            account_login=account.get("login", "unknown"),
            account_type=account.get("type", "User"),
            target_id=installation.get("target_id", account.get("id", 0)),
            target_type=installation.get("target_type", account.get("type", "User")),
            status="suspended" if action == "suspend" else "deleted",
        )
        logger.info(f"GitHub App installation {inst_id} marked as {action}.")

    return {"status": "success", "action": action, "installation_id": inst_id}


@router.get("/install")
async def get_install_url(
    user: User = Depends(require_auth),
    app_service: GitHubAppService = Depends(get_app_service),
):
    """Return the GitHub App installation URL for the authenticated user."""
    install_url = app_service.get_installation_url()
    if not install_url:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "message": "GitHub App installation URL is not configured.",
                "missing_configuration": app_service.get_configuration_issues(),
            },
        )
    return {
        "install_url": install_url,
        "configured": app_service.has_app_credentials(),
        "has_install_url": True,
        "missing_configuration": app_service.get_configuration_issues(),
    }


@router.get("/callback")
async def installation_callback(
    installation_id: int | None = None,
    setup_action: str | None = None,
    user: User | None = Depends(get_current_user_optional),
    app_service: GitHubAppService = Depends(get_app_service),
):
    """Return from GitHub App setup, sync accessible installations, and open the dashboard."""
    if user:
        oauth_token = await get_oauth_token(user.id)
        await app_service.sync_user_installations(
            user.id, oauth_token.access_token if oauth_token else ""
        )
        if installation_id and app_service.is_configured():
            await app_service.sync_installation_from_github(
                installation_id, user_id=user.id
            )
    return RedirectResponse(url="/#/dashboard", status_code=status.HTTP_302_FOUND)


async def _verify_webhook_signature(request: Request) -> None:
    """Verify GitHub's sha256 webhook signature before accepting lifecycle events."""
    secret = os.getenv("GITHUB_WEBHOOK_SECRET", "")
    if not secret:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Webhook secret is not configured.",
        )
    signature = request.headers.get("X-Hub-Signature-256", "")
    expected = (
        "sha256="
        + hmac.new(secret.encode(), await request.body(), hashlib.sha256).hexdigest()
    )
    if not hmac.compare_digest(signature, expected):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid GitHub webhook signature.",
        )


# Convenience / Alias Endpoints


@router.get("/status")
async def get_app_status_endpoint(
    user: User = Depends(require_auth),
    app_service: GitHubAppService = Depends(get_app_service),
):
    """Returns general GitHub App installation status for the authenticated user."""
    installations = await get_installations_for_user(user.id)
    active_count = sum(
        1 for i in installations if i.status == InstallationStatus.ACTIVE
    )
    install_url = app_service.get_installation_url()
    return {
        "status": (
            "installed"
            if active_count > 0
            else (
                "not_configured"
                if not app_service.has_app_credentials()
                else "not_installed"
            )
        ),
        "installations_count": len(installations),
        "active_installations": active_count,
        "connected_account": installations[0].account_login if installations else None,
        "configured": app_service.has_app_credentials(),
        "install_url": install_url or None,
        "has_install_url": bool(install_url),
        "missing_configuration": app_service.get_configuration_issues(),
    }


# Router aliases mounted directly under /api prefix for repository and org management
repo_alias_router = APIRouter(prefix="/api/repositories", tags=["Repository Alias"])


@repo_alias_router.get("")
async def alias_list_repositories(
    user: User = Depends(require_auth),
    app_service: GitHubAppService = Depends(get_app_service),
):
    """Lists repositories across all installations for the authenticated user."""
    return await list_user_installations(user=user, app_service=app_service)


@repo_alias_router.get("/organizations")
async def alias_list_organizations(user: User = Depends(require_auth)):
    """Lists organization accounts associated with user's installations."""
    installations = await get_installations_for_user(user.id)
    orgs = [
        {
            "id": inst.id,
            "login": inst.account_login,
            "type": inst.account_type.value,
            "status": inst.status.value,
        }
        for inst in installations
    ]
    return {"organizations": orgs}
